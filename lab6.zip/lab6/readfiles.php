<?php
$files = '';
//Read all files in the uploads folder
foreach (glob("uploads/*.*") as $filename) {
$files = $files . "&" . $filename ;
}
echo $files;
?>
