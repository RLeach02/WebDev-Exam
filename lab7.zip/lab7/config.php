<?php
$servername = "localhost";
$username = "root";
$password = "5AMblops"; //Your password here
$dbname = "lab7";
$link = mysqli_connect($servername, $username, $password, $dbname);
?>
