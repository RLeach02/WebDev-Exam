<?php
$fileName = $_GET['fileName'];
unlink($fileName);
?>
