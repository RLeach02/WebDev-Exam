var express = require('express');
var router = express.Router();

var database = require('../database');

// Function to hash a password and return the hash
const crypto = require('crypto');
var multer = require('multer');
var upload = multer({dest:'./upload/'});
var path = require('path');
var fs = require('fs');



function hashPassword(password) {
    const hash = crypto.createHash('sha256').update(password).digest('hex');
    return hash;
  } 


/* GET home page. */
router.get('/', function(req, res, next) {
  //var ip = req.headers['x-real-ip'] || req.connection.remoteAddress;
  //req.session.ip = ip;
  //console.log(req.session.ip);
  res.render('index', { title: 'Express', session : req.session });
});

// Get Sign up page
router.get('/signup', function(req, res, next) {
    res.render('signup', { title: 'Express', session : req.session });
  });

// Get Menu page
router.get('/menu', function(req, res, next) {
  
    res.render('menu', { title: 'Express', session : req.session });
  });

// Login API function
router.post('/login', async function(req, res, next){
  
    //console.log(req.body);
    const { email, password } = req.body;
    //console.log(req.session.ip);
    const hashedPassword = hashPassword(password);
    
    // Check if username and password match
    const query = `SELECT * FROM users WHERE email = '${email}' AND password = '${hashedPassword}'`;
    database.query(query, (err, data) => {
           // console.log(data);
            if(data.length > 0)
            {
                for(var count = 0; count < data.length; count++)
                {
                    if(data[count].password == hashedPassword)
                    {
                        req.session.user_id = data[count].id;
                        req.session.user_role = data[count].role;
                        //console.log(data[count].role);
                        res.redirect("/");
                    }
                    else
                    {
                        res.send('Incorrect Password');
                    }
                }
            }
            else
            {
                res.send('Incorrect Email Address');
            }
            res.end();
        });
    

});

// Logout API function
router.get('/logout', function(request, response, next){

    request.session.destroy();

    response.redirect("/");

});

// Join API function to sign up a new member. 
router.post('/join', async function(req, res, next) {

                const { name, email, password, password2 } = req.body;
                if (password != password2){
                  
                  res.status(406).send('Passwords do not match');
                  
                }
                else{
                      hashedPassword = hashPassword(password);
                      // Check if username already exists
                      const checkQuery = `SELECT * FROM users WHERE email = '${email}'`;
                      database.query(checkQuery, (err, results) => {
                        if (err) throw err;
                        if (results.length > 0) {
                          res.status(409).send('Username already exists');
                        } else {
                          // Insert new user into database
                          // The role of the new member would be customer
                          const insertQuery = `INSERT INTO users (name, email, password, role) VALUES ('${name}','${email}', '${hashedPassword}',"customer")`;
                          database.query(insertQuery, (err, result) => {
                            if (err) throw err;
                            res.status(201).send('User created successfully');
                          });
                        }
                      });
                    }
});

// API function to retrieve all menu items from the database
router.get('/allItems', function(req, res){
    var result = [];    
    database.query('SELECT * from menus', (err, rows, fields) => {
      if (err) throw err
      for (var i=0 ; i< rows.length; i++){
        result[i] = rows[i];
      }  
      res.send(result);
    })
     });

// API function to add a new menu item to the database
router.post('/addItem', upload.single('pic'), function(req, res) {
        if (!req.body.item || !req.body.description ||!req.body.price ){
            res.statusCode = 400;
                res.end( 'Invalid form data');
            }
          
        else {
                var oldpath = req.file.destination+req.file.filename;
                var newpath = 'upload/' + req.file.originalname;
                fs.rename(oldpath, newpath, function (err) {
                  if (err) throw err;
                  
                });
                const name = req.body.item;
                const description = req.body.description;
                const price = req.body.price;
                const picFile =newpath;
          
                const myQuery = `INSERT INTO menus (name, description, price, picture) VALUES("${name}","${description}","${price}","${newpath}")`;
                console.log(myQuery);
                database.query(myQuery, (err, rows, fields) => {
                if (err) {
                        res.statusCode = 500;
                        res.end( 'Error in SQL query');
                    }
                else{
                        res.statusCode = 200;
                        res.end( 'Success');
                }
                        
                        
                })
            }
       
       });

// Delete an item
router.delete('/deleteItem/:name', function(req, res){
database.query(`DELETE from menus where name="${req.params.name}"`, (err, rows, fields) => {
    if (err) {
          res.statusCode = 500;
          res.end( 'Error in SQL query');
    }
    else {
        res.statusCode = 200;
        res.send('Success');
      }
  })
});


// This API function returns the picture of a menu item
router.get('/upload/:filename',function(req, res, next){
        const filename = req.params.filename;
        res.sendFile(process.cwd() + '/upload/'+ filename);
    });
module.exports = router;
