<?php
if(!empty($_FILES['files'])){
$targetDir = "uploads/";
$targetFile = $targetDir.$_POST["fileName"];
if (move_uploaded_file($_FILES["files"]["tmp_name"][0], $targetFile)) {
echo "The file ". htmlspecialchars( basename(
$_FILES["files"]["name"][0])). " has been uploaded.";
} else {
echo "Sorry, there was an error uploading your file.";
}
}
?>
