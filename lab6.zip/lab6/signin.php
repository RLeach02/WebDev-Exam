<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet"
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-
awesome.min.css">
<link rel="stylesheet"
href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<div class="container">
<h1>Sign In</h1>
<form onsubmit="signIn()" action="task2.html">
<div class="form-group">
<label for="email">Email:</label>
<input type="email" class="form-control" id="email"
placeholder="Enter email" name="email">
</div>
<div class="form-group">
<label for="pwd">Password:</label>
<input type="password" class="form-control" id="pwd"
placeholder="Enter password" name="pwd">
</div>
<div class="checkbox">
<label><input type="checkbox" name="remember"> Remember
me</label>
</div>
<button type="submit" class="btn btn-success">Sign
in</button>
</form>
</div>
</body>
<script>
function signIn(){
    if (document.getElementById('email').value == 'james@gmail.com')
        localStorage.setItem('userType','admin');
        else
        localStorage.setItem('userType','customer');
}