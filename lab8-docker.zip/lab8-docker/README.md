If laravel was installed using Docker.

https://laravel.com/docs/10.x/installation#next-steps

Using this command:
```
curl -s "https://laravel.build/example-app" | bash
```

Copy all these files into the folder, and run the container using:

```
./vendor/bin/sail up
```

You may need to update the SQL details in the .env file.

For other laravel install should just be able to copy the files to the directory and get it working.